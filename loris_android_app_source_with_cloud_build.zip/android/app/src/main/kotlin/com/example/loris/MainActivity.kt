package com.example.loris

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
