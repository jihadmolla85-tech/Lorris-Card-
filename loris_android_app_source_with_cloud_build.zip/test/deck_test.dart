import 'package:flutter_test/flutter_test.dart';
import 'package:loris/game/card.dart';
import 'package:loris/game/deck.dart';

void main() {
  test('৪ জনের ডেকে ৩২টি কার্ড ও একটি LORIS', () {
    final d = DeckFactory.create(GameMode.four);
    expect(d.length, 32);
    expect(d.where((c) => c.isLoris).length, 1);
  });
  test('৬ জনের ডেকে ৪৮টি কার্ড ও একটি LORIS', () {
    final d = DeckFactory.create(GameMode.six);
    expect(d.length, 48);
    expect(d.where((c) => c.isLoris).length, 1);
  });
}
