import 'package:flutter/material.dart';
import 'screens/home_screen.dart';

void main() => runApp(const LorisApp());

class LorisApp extends StatelessWidget {
  const LorisApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LORIS',
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        colorScheme: ColorScheme.fromSeed(seedColor: const Color(0xff146b4b), brightness: Brightness.dark),
        scaffoldBackgroundColor: const Color(0xff082d25),
        useMaterial3: true,
        cardTheme: const CardThemeData(color: Color(0xff124638)),
      ),
      home: const HomeScreen(),
    );
  }
}
