import 'package:flutter/material.dart';
import '../game/card.dart';
import '../game/game_engine.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});
  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  GameMode mode = GameMode.four;
  LorisGame? game;
  int selectedBid = 5;
  Suit selectedTrump = Suit.spades;
  bool started = false;

  void startGame() {
    setState(() {
      game = LorisGame(mode: mode);
      game!.start();
      started = true;
    });
  }

  void runBots() {
    if (game == null || game!.finished) return;
    while (game!.currentPlayer != 0 && !game!.finished) {
      final g = game!;
      if (g.callerTeam == null) {
        g.setBid(1, 5, Suit.spades);
      }
      final legal = g.legalCards(g.currentPlayer);
      if (legal.isEmpty) break;
      g.play(g.currentPlayer, legal.first);
    }
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final g = game;
    return Scaffold(
      appBar: AppBar(title: const Text('LORIS • লরিস'), centerTitle: true),
      body: SafeArea(
        child: !started || g == null ? _setup() : _table(g),
      ),
    );
  }

  Widget _setup() => Center(
    child: Padding(
      padding: const EdgeInsets.all(24),
      child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
        const Icon(Icons.style, size: 72, color: Color(0xffe5c66b)),
        const SizedBox(height: 16),
        const Text('LORIS', style: TextStyle(fontSize: 36, fontWeight: FontWeight.bold, letterSpacing: 4)),
        const Text('কার্ড গেম', style: TextStyle(fontSize: 18)),
        const SizedBox(height: 28),
        const Text('খেলোয়াড় সংখ্যা'),
        const SizedBox(height: 10),
        SegmentedButton<GameMode>(
          segments: const [
            ButtonSegment(value: GameMode.four, label: Text('৪ জন')),
            ButtonSegment(value: GameMode.six, label: Text('৬ জন')),
          ],
          selected: {mode},
          onSelectionChanged: (s) => setState(() => mode = s.first),
        ),
        const SizedBox(height: 24),
        FilledButton.icon(onPressed: startGame, icon: const Icon(Icons.play_arrow), label: const Text('AI-এর বিরুদ্ধে খেলুন')),
        const SizedBox(height: 10),
        const Text('Bluetooth multiplayer পরবর্তী সংস্করণে যুক্ত হবে।', textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white70)),
      ]),
    ),
  );

  Widget _table(LorisGame g) {
    final hand = g.hands[0];
    return Column(children: [
      Padding(
        padding: const EdgeInsets.all(12),
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _scoreBox('টিম ১', g.scores[0]),
          _scoreBox('টিম ২', g.scores[1]),
          _scoreBox('ডিলার', g.seatName(g.dealer)),
        ]),
      ),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
        child: Text(g.status, textAlign: TextAlign.center, style: const TextStyle(fontSize: 16)),
      ),
      if (g.callerTeam == null && !g.finished)
        _bidding(g),
      Expanded(
        child: Center(
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 8, runSpacing: 8,
            children: g.trick.map((p) => _cardFace(p.card, '${p.seat + 1}')).toList(),
          ),
        ),
      ),
      if (!g.finished && g.currentPlayer == 0)
        Padding(
          padding: const EdgeInsets.all(8),
          child: Wrap(
            alignment: WrapAlignment.center,
            spacing: 6, runSpacing: 8,
            children: hand.map((c) {
              final legal = g.canPlay(0, c);
              return Opacity(
                opacity: legal ? 1 : .35,
                child: InkWell(
                  onTap: legal ? () {
                    setState(() => g.play(0, c));
                    runBots();
                  } : null,
                  child: _cardFace(c, ''),
                ),
              );
            }).toList(),
          ),
        ),
      if (g.finished)
        FilledButton(onPressed: () => setState(() => g.deal()), child: const Text('পরের ডিল')),
      const SizedBox(height: 10),
      TextButton(onPressed: () => setState(() { started = false; game = null; }), child: const Text('নতুন গেম')),
    ]);
  }

  Widget _bidding(LorisGame g) => Card(
    margin: const EdgeInsets.all(12),
    child: Padding(
      padding: const EdgeInsets.all(12),
      child: Column(children: [
        const Text('বিডিং • আপনার টিমের কল'),
        Row(mainAxisAlignment: MainAxisAlignment.center, children: [
          DropdownButton<int>(value: selectedBid, items: [5,6,7,8].map((n) => DropdownMenuItem(value: n, child: Text('$n'))).toList(),
            onChanged: (v) => setState(() => selectedBid = v!)),
          const SizedBox(width: 12),
          DropdownButton<Suit>(value: selectedTrump, items: Suit.values.map((s) => DropdownMenuItem(value: s, child: Text(s.symbol))).toList(),
            onChanged: (v) => setState(() => selectedTrump = v!)),
          FilledButton(onPressed: () => setState(() { g.setBid(0, selectedBid, selectedTrump); runBots(); }), child: const Text('কল করুন')),
        ]),
      ]),
    ),
  );

  Widget _scoreBox(String label, int score) => Column(children: [
    Text(label, style: const TextStyle(color: Colors.white70)),
    Text('$score', style: const TextStyle(fontSize: 24, fontWeight: FontWeight.bold)),
  ]);

  Widget _cardFace(PlayingCard c, String small) {
    final isRed = !c.isLoris && c.suit!.red;
    return Container(
      width: 54, height: 78,
      decoration: BoxDecoration(color: const Color(0xfff8f5e9), borderRadius: BorderRadius.circular(8),
        border: Border.all(color: const Color(0xffc9bd9d), width: 1.2)),
      child: Center(child: Text(c.label, textAlign: TextAlign.center,
        style: TextStyle(color: c.isLoris ? const Color(0xff146b4b) : (isRed ? Colors.red : Colors.black87),
          fontWeight: FontWeight.bold, fontSize: c.isLoris ? 13 : 19))),
    );
  }
}
