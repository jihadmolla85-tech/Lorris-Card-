import 'dart:math';
import 'card.dart';
import 'deck.dart';

class TrickPlay {
  final int seat;
  final PlayingCard card;
  const TrickPlay(this.seat, this.card);
}

class LorisGame {
  final GameMode mode;
  final int playerCount;
  final List<int> teamBySeat;
  final Random _random;
  late List<List<PlayingCard>> hands;
  late List<int> scores;
  late int dealer;
  late int currentPlayer;
  late int leader;
  late List<TrickPlay> trick;
  Suit? trump;
  int? callerTeam;
  int call = 0;
  int tricksThisHand = 0;
  int team0Tricks = 0;
  int team1Tricks = 0;
  bool special16 = false;
  int? specialCallerTeam;
  bool finished = false;
  String status = 'নতুন খেলা শুরু করুন';

  LorisGame({required this.mode, List<int>? teamBySeat, Random? random})
      : playerCount = mode == GameMode.four ? 4 : 6,
        teamBySeat = teamBySeat ?? List.generate(mode == GameMode.four ? 4 : 6, (i) => i.isEven ? 0 : 1),
        _random = random ?? Random() {
    if (this.teamBySeat.length != playerCount) {
      throw ArgumentError('প্রতিটি সিটের জন্য একটি টিম নির্ধারণ করতে হবে');
    }
    scores = [0, 0];
    hands = List.generate(playerCount, (_) => <PlayingCard>[]);
    trick = [];
    dealer = 0;
    currentPlayer = 1;
    leader = 1;
  }

  int nextSeat(int seat) => (seat + 1) % playerCount;
  int teamOf(int seat) => teamBySeat[seat];

  void start() {
    final selectionDeck = DeckFactory.create(mode, random: _random);
    var cursor = 0;
    var recipient = 0;
    while (cursor < selectionDeck.length) {
      final card = selectionDeck[cursor++];
      if (!card.isLoris && card.rank == 11) {
        dealer = recipient;
        break;
      }
      recipient = nextSeat(recipient);
    }
    deal();
  }

  void deal() {
    final deck = DeckFactory.create(mode, random: _random);
    hands = List.generate(playerCount, (_) => <PlayingCard>[]);
    var p = 0;
    for (final c in deck) {
      hands[p].add(c);
      p = nextSeat(p);
    }
    // A hand containing eight cards all below 10 cancels the deal.
    final invalid = hands.any((h) => h.length == 8 &&
        h.every((c) => !c.isLoris && c.rank! < 10));
    if (invalid) {
      status = 'একজন খেলোয়াড়ের ৮টি কার্ডই ১০-এর নিচে—ডিল বাতিল, আবার ডিল করুন';
      deal();
      return;
    }
    for (final h in hands) {
      h.sort(_compareCards);
    }
    trump = null;
    callerTeam = null;
    call = 0;
    trick = [];
    tricksThisHand = 0;
    team0Tricks = 0;
    team1Tricks = 0;
    special16 = false;
    specialCallerTeam = null;
    finished = false;
    leader = nextSeat(dealer);
    currentPlayer = leader;
    status = 'ডিল সম্পন্ন। ${seatName(leader)} প্রথম চাল দেবে।';
  }

  String seatName(int seat) => seat == 0 ? 'আপনি' : 'খেলোয়াড় ${seat + 1}';

  int _compareCards(PlayingCard a, PlayingCard b) {
    if (a.isLoris) return b.isLoris ? 0 : 1;
    if (b.isLoris) return -1;
    final s = a.suit!.index.compareTo(b.suit!.index);
    return s != 0 ? s : a.rank!.compareTo(b.rank!);
  }

  bool canPlay(int seat, PlayingCard card) {
    if (finished || seat != currentPlayer || !hands[seat].contains(card)) return false;
    if (card.isLoris) return true;
    if (trick.isEmpty) return true;
    final ledSuit = trick.first.card.suit;
    final hasLed = hands[seat].any((c) => !c.isLoris && c.suit == ledSuit);
    if (hasLed && card.suit != ledSuit) return false;

    final highestTrump = _highestTrumpInTrick();
    if (highestTrump != null && trump != null && teamOf(seat) != -1) {
      final hasHigher = hands[seat].any((c) => !c.isLoris && c.suit == trump &&
          c.rank! > highestTrump.rank!);
      if (hasHigher && card.suit == trump && card.rank! <= highestTrump.rank!) return false;
      if (hasHigher && card.suit != trump) return false;
    }
    return true;
  }

  PlayingCard? _highestTrumpInTrick() {
    if (trump == null) return null;
    PlayingCard? best;
    for (final p in trick) {
      final c = p.card;
      if (!c.isLoris && c.suit == trump &&
          (best == null || c.rank! > best.rank!)) best = c;
    }
    return best;
  }

  void play(int seat, PlayingCard card) {
    if (!canPlay(seat, card)) return;
    hands[seat].remove(card);
    trick.add(TrickPlay(seat, card));
    if (trick.length < playerCount) {
      currentPlayer = nextSeat(seat);
      status = '${seatName(currentPlayer)}-এর চাল';
      return;
    }
    final winner = _trickWinner();
    if (teamOf(winner) == 0) {
      team0Tricks++;
    } else {
      team1Tricks++;
    }
    tricksThisHand++;
    leader = winner;
    currentPlayer = winner;
    trick = [];
    status = '${seatName(winner)} বোর্ড জিতেছে';
    if (hands.every((h) => h.isEmpty)) _finishHand();
  }

  int _trickWinner() {
    final loris = trick.where((p) => p.card.isLoris).toList();
    if (loris.isNotEmpty) return loris.first.seat;
    final led = trick.first.card.suit;
    TrickPlay best = trick.first;
    int strength(PlayingCard c) {
      if (trump != null && c.suit == trump) return 100 + c.rank!;
      if (c.suit == led) return c.rank!;
      return -1;
    }
    for (final p in trick.skip(1)) {
      if (strength(p.card) > strength(best.card)) best = p;
    }
    return best.seat;
  }

  void setBid(int team, int amount, Suit suit) {
    if (amount < 5 || amount > 8) throw ArgumentError('সাধারণ কল ৫ থেকে ৮');
    callerTeam = team;
    call = amount;
    trump = suit;
    status = 'টিম ${team + 1} $amount কল করেছে; ট্রাম্প ${suit.label}';
  }

  void callSixteen(int team) {
    if (team != teamOf(leader) || tricksThisHand < call) {
      throw StateError('টার্গেট পূরণকারী বোর্ডজয়ী খেলোয়াড়ের টিমই ১৬ কল করতে পারে');
    }
    special16 = true;
    specialCallerTeam = team;
    status = '১৬ কল! বাকি সব বোর্ড জিততে হবে।';
  }

  void _finishHand() {
    if (special16) {
      final won = (specialCallerTeam == 0 ? team0Tricks : team1Tricks) == 8;
      scores[won ? specialCallerTeam! : 1 - specialCallerTeam!] += 16;
    } else if (callerTeam != null) {
      final wonTricks = callerTeam == 0 ? team0Tricks : team1Tricks;
      if (wonTricks >= call) {
        scores[callerTeam!] += call;
      } else {
        scores[1 - callerTeam!] += call * 2;
      }
    }
    status = 'হাত শেষ। স্কোর: ${scores[0]} - ${scores[1]}';
    finished = true;
    if (scores[0] >= 32 || scores[1] >= 32) {
      status = 'টিম ${scores[0] >= 32 ? 1 : 2} জিতেছে!';
      return;
    }
    if (scores[teamOf(dealer)] > scores[1 - teamOf(dealer)]) {
      dealer = nextSeat(dealer);
    }
  }

  List<PlayingCard> legalCards(int seat) =>
      hands[seat].where((c) => canPlay(seat, c)).toList();
}
