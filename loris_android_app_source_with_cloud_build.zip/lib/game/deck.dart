import 'dart:math';
import 'card.dart';

class DeckFactory {
  static List<PlayingCard> create(GameMode mode, {Random? random}) {
    final min = mode == GameMode.four ? 7 : 3;
    final cards = <PlayingCard>[];
    for (final suit in Suit.values) {
      for (var rank = min; rank <= 14; rank++) {
        if (suit == Suit.spades && rank == min) {
          cards.add(const PlayingCard.loris());
        } else {
          cards.add(PlayingCard.normal(suit, rank));
        }
      }
    }
    (random ?? Random()).shuffle(cards);
    return cards;
  }

  static int get playerCount => 0;
}
