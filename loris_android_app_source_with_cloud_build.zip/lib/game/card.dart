enum Suit { spades, hearts, diamonds, clubs }

extension SuitText on Suit {
  String get symbol => switch (this) {
    Suit.spades => '♠',
    Suit.hearts => '♥',
    Suit.diamonds => '♦',
    Suit.clubs => '♣',
  };
  String get label => switch (this) {
    Suit.spades => 'স্পেড',
    Suit.hearts => 'হার্ট',
    Suit.diamonds => 'ডায়মন্ড',
    Suit.clubs => 'ক্লাব',
  };
  bool get red => this == Suit.hearts || this == Suit.diamonds;
}

enum GameMode { four, six }

class PlayingCard {
  final Suit? suit;
  final int? rank;
  final bool isLoris;
  const PlayingCard.normal(this.suit, this.rank) : isLoris = false;
  const PlayingCard.loris() : suit = null, rank = null, isLoris = true;

  String get label {
    if (isLoris) return 'LORIS';
    final r = switch (rank!) {
      11 => 'J', 12 => 'Q', 13 => 'K', 14 => 'A', _ => '$rank'
    };
    return '${suit!.symbol}$r';
  }

  @override
  String toString() => label;
}
